import { Component, OnInit } from "@angular/core";
import { TableService } from "../api/table.service";
@Component({
  selector: "app-table",
  templateUrl: "./table.page.html",
  styleUrls: ["./table.page.scss"],
})
export class TablePage implements OnInit {
  tabledata: any = [];
  expanded = false;
  constructor(public TableService: TableService) {}

  ngOnInit() {
    this.getTableData();
  }
  getTableData() {
    this.expanded = false;
    this.TableService.getTableData().subscribe((data) => {
      var anyData = <any>data;
      this.tabledata = anyData.slice(0, 9);
    });
  }
  // getTableData() {
  //   this.TableService.getTableData().subscribe((data) => {
  //     var anyData = <any>data;
  //     // var slicedData: [];
  //     this.tabledata = anyData.data;
  //     // slicedData = anyData.slice(9);
  //     // console.log("i am fired", anyData.slice(0, 9));
  //     // console.log("i am fired2", slicedData);
  //     return anyData.slice(0, 9);
  //   });
  // }
  onClickupTask() {
    alert("Ascending Sorting according to task");
  }

  onClickDownTask() {
    alert("Descending Sorting according to task");
  }

  onClickupOverSpeed() {
    alert("Ascending Sorting according to Over Speed");
  }

  onClickDownOverSpeed() {
    alert("Descending Sorting according to Over Speed");
  }

  onClickupPostedSpeed() {
    alert("Descending Sorting according to Posted Speed");
  }
  onClickDownPostedSpeed() {
    alert("Descending Sorting according to Posted Speed");
  }

  onClickupDuration() {
    alert("Descending Sorting according to Posted Speed");
  }
  onClickDownDuration() {
    alert("Descending Sorting according to Posted Speed");
  }

  onClickExpand() {
    // alert("Expand table");
    this.expanded = true;
    this.TableService.getTableData().subscribe((data) => {
      var anyData = <any>data;
      this.tabledata = anyData;
      console.log("in expand", anyData);
    });
  }
}
